// Copyright (C) 2007  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_BAYES_UTILs_H_
#define DLIB_BAYES_UTILs_H_ 

#include "bayes_utils/bayes_utils.h"

#endif // DLIB_BAYES_UTILs_H_ 



